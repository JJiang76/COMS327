typedef struct room room_t;

void setup(int dungeon[21][80]);

room_t *generate_dungeon(int dungeon[21][80]);

void print_dungeon(int dungeon[21][80]);
