void setup(int dungeon[21][80]);

void print_dungeon(int dungeon[21][80]);
