#define WORLD_SIZE 23

void topple(int x, int y, int table[WORLD_SIZE][WORLD_SIZE]);

void drop(int table[WORLD_SIZE][WORLD_SIZE]);

void print_table(int table[WORLD_SIZE][WORLD_SIZE]);
